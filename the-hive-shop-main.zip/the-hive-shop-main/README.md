# The Hive Shop (Android Version)

- Python server [here](https://github.com/doctor-blue/the-hive-shop-server)
- Flutter version [here](https://github.com/doctor-blue/the-hive-shop-flutter)
- React Native version: comming soon.
